#include <stdio.h>
#include <stdlib.h>

/* function definitions */
void *bubble_sort(void*);
void *merge(void*);

int main (int argc, const char * argv[]) 
{
	/* Use STDIN (e.g. scanf, cin) to take the input */
	/*
		your code here
	*/

	/* Do the sorting */

	/* Use STDOUT (e.g. printf, cout) to output the sorted array */
	/*
		your code here
	*/

    return 0;
}

void *bubble_sort(void *input_tinfo){



}

void *merge(void *input_tinfo){



}
